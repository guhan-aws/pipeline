#!/bin/bash
systemctl start httpd
systemctl enable httpd